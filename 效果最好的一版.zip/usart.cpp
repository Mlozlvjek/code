/**
  * @file		uart.c
  * @author		Hill
  * @copyright	Hill
  * @date		2021-03-23
  * @version	V1.0
  * @brief		uart basic operation
  * @attention	NONE
  */
#include<stdio.h>	//standard input/output definitions
#include<stdlib.h>  //standard functions
#include<string.h>	//string function definitions
#include<fcntl.h>	//file control definitions
#include<termios.h>	//POSIX terminal control definitions
#include "usart.h"

//-----------------------------------------------------------------------------
int com_dev_open(int com_num);
int com_dev_set_baud_rate(int fd, int baud_rate);
int com_dev_set_data_bits(int fd, int data_bits);
int com_dev_set_stop_bits(int fd, int stop_bits);
int com_dev_set_parity(int fd, char parity);
int com_dev_set_flow_ctontrl(int fd, COM_FLOW_CONTROL_TYPE flow_control);

void set_fl(int fd, int flags)
{
	int val;
	if((val = fcntl(fd,F_GETFL,0)) < 0)
		perror("fcntli get");
	val |= flags;
	if(fcntl(fd,F_SETFL,val) < 0)
		perror("fcntl set");
}

//-----------------------------------------------------------------------------
/**
  * @brief  open com port accroding to the specifications
  * @param  com_num:	com port number COM1 COM2 COM3 ...
  * @param  baud_rate:	com port baud rate e.g. 9600
  * @param  data_bits:	data bits in a package 5,6,7,8
  * @param  stop_bits:	stop bits in a package 1,2
  * @param  parity
  *		@arg	'N','n':	no parity
  *		@arg	'O','o':	odd parity
  *		@arg	'E','e':	even parity
  * @param  flow_control
  *		@arg	COM_FLOW_CONTROL_NONE:	no flow control
  *		@arg	COM_FLOW_CONTROL_HARD:	hardware flow control
  *		@arg	COM_FLOW_CONTROL_SOFT:	software flow control
  * @retval: file discriptor, a negative number means there is some error
  * @attention NONE
  */
int com_open(int com_num, int baud_rate,int data_bits, int stop_bits,
			 char parity, COM_FLOW_CONTROL_TYPE flow_control)
{
	int errCode = 0, fd;
	//
	fd = com_dev_open(com_num);
	if(fd<0)
	{
		return fd;
	}
	errCode |= com_dev_set_baud_rate(fd, baud_rate);
	errCode |= com_dev_set_data_bits(fd, data_bits);
	errCode |= com_dev_set_stop_bits(fd, stop_bits);
	errCode |= com_dev_set_parity(fd, parity);
	errCode |= com_dev_set_flow_ctontrl(fd, flow_control);
	
	set_fl(fd, O_NONBLOCK);

	return (errCode == 0)?fd:-1;
}
//-----------------------------------------------------------------------------
/**
  * @brief  open com device as a file
  * @param  com_num:	com port number COM1 COM2 COM3 ...
  * @retval: file discriptor, a negative number means there is some error
  * @attention NONE
  */
int com_dev_open(int com_num)
{
	int fd;
	char com_name[20] = "/dev/ttyTHS";
	struct termios options;

	//assert the com number
	if (com_num < 0 || com_num>5)
	{
		return -1;
	}
	//form the device name
	sprintf(com_name + 11, "%d", com_num);
	//open com device
	fd = open(com_name, O_RDWR  |//read and write mode
						O_NOCTTY|//to avoid keyboard abort signals and soforth 
								 //affect your process.
						O_NDELAY);//to avoid your process be put to sleep when
								  //the DCD signal line is invalid
	if (fd < 0)
	{
		return -1;
	}
	//a read call will block (wait) until characters come in
	if(fcntl(fd, F_SETFL, 0) < 0)
	{
		return -1;
	}
	//get current options
	if (tcgetattr(fd, &options) != 0)
	{
		return -1;
	}
	options.c_cflag |= CREAD|	//enable receiver
					   CLOCAL;	//ensure your program is not the "only" owner 
								//of the com port, so that the driver can read 
								//the incoming bytes
	//choosing raw input
	options.c_lflag &= ~(ICANON |	//disabel canonical input( use raw)
						 ECHO   |	//disabel echoing of input characters
						 ECHOE  |	//do not echo erase character
						 ISIG	|	//disabel SIGINTR,SIGSUSP,SIGDSUSP,and
									//SIGQUIT signals
						 NOFLSH);	//disabel flushing of input buffers after 
									//interrupt or qiut characters
	//choosing raw output
	options.c_oflag &= ~OPOST;
	//specify packet size and packet timeouts
	options.c_cc[VMIN]  = 1;//minumum number of characters to read
	options.c_cc[VTIME] = 0;//time to wait for data (in tenths of seconds)
	//discard data in the input buffer and output buffer
	options.c_iflag &= ~ICRNL;
	tcflush(fd,TCIFLUSH);
	
	//set options to device and return
	return	(tcsetattr(fd, TCSANOW, &options) != 0) ? -1 : fd;
}

////bak
//int com_dev_open(int com_num)
//{
//	int fd;
//	char com_name[20] = "/dev/ttyS";
//	struct termios options;
//
//	//assert the com number
//	if (com_num < 0 || com_num>3)
//	{
//		return -1;
//	}
//	//form the device name
//	sprintf(com_name + 9, "%d", com_num);
//	//open com device
//	fd = open(com_name, O_RDWR  |//read and write mode
//						O_NOCTTY|//to avoid keyboard abort signals and soforth 
//								 //affect your process.
//						O_NDELAY);//to avoid your process be put to sleep when
//								  //the DCD signal line is invalid
//	if (fd < 0)
//	{
//		return -1;
//	}
//	//a read call will block (wait) until characters come in
//	if(fcntl(fd, F_SETFL, 0) < 0)
//	{
//		return -1;
//	}
//	//get current options
//	if (tcgetattr(fd, &options) != 0)
//	{
//		return -1;
//	}
//	options.c_cflag |= CREAD|	//enable receiver
//					   CLOCAL;	//ensure your program is not the "only" owner 
//								//of the com port, so that the driver can read 
//								//the incoming bytes
//	//choosing raw input
//	options.c_lflag &= ~(ICANON |	//disabel canonical input( use raw)
//						 ECHO   |	//disabel echoing of input characters
//						 ECHOE  |	//do not echo erase character
//						 ISIG	|	//disabel SIGINTR,SIGSUSP,SIGDSUSP,and
//									//SIGQUIT signals
//						 NOFLSH);	//disabel flushing of input buffers after 
//									//interrupt or qiut characters
//	//choosing raw output
//	options.c_oflag &= ~OPOST;
//	//specify packet size and packet timeouts
//	options.c_cc[VMIN]  = 1;//minumum number of characters to read
//	options.c_cc[VTIME] = 0;//time to wait for data (in tenths of seconds)
//	//discard data in the input buffer and output buffer
//	options.c_iflag &= ~ICRNL;
//	tcflush(fd,TCIFLUSH);
//	
//	//set options to device and return
//	return	(tcsetattr(fd, TCSANOW, &options) != 0) ? -1 : fd;
//}

//-----------------------------------------------------------------------------
/**
  * @brief	find the flag to be set to the system according to baud rate
  * @param  p_flag:		pointer to the flag found
  * @param  baud_rate:	com port baud rate e.g. 9600
  * @retval err code:	0-success, other - error number
  * @attention NONE
  */
int baud_rate_to_flag(speed_t *p_flag, int baud_rate)
{
	int   	bd_rates[] = {  300, 600, 1200, 2400, 4800, 9600, 19200, 38400,
		 57600, 115200, 230400, 460800, 500000, 576000, 921600};
	speed_t bd_flags[] = { B300,B600,B1200,B2400,B4800,B9600,B19200,B38400,
		B57600,B115200,B230400,B460800,B500000,B576000,B921600};
	int k = 0, arrSize;
	//
	arrSize = sizeof(bd_rates) / sizeof(int);
	while (k < arrSize&&baud_rate != bd_rates[k])
	{
		k++;
	}
	if (k < arrSize)
	{
		*p_flag= bd_flags[k];
		return 0;
	}
	else
	{
		*p_flag = B9600;//useless
		return -1;
	}
}
//-----------------------------------------------------------------------------
/**
  * @brief  set the baud to the com port  
  * @param  flow_control
  *		@arg COM_FLOW_CONTROL_NONE: no flow control
  *		@arg COM_FLOW_CONTROL_HARD: hardware flow control
  *		@arg COM_FLOW_CONTROL_SOFT: software flow control
  * @param  fd: file discriptor represent the com port file
  * @param  baud_rate:	com port baud rate e.g. 9600
  * @retval err code: 0-success, other - error number
  * @attention NONE
  */
int com_dev_set_baud_rate(int fd, int baud_rate)
{
	speed_t baud_rate_flag;
	struct termios options;
	
	//assert the baud rate
	if (baud_rate_to_flag(&baud_rate_flag, baud_rate) != 0)
	{
		return -1;
	}
	//get current options
	if (tcgetattr(fd, &options) != 0)
	{
		return -1;
	}
	//form options
	cfsetispeed(&options, baud_rate_flag);
	cfsetospeed(&options, baud_rate_flag);
	//discard data in the input buffer and output buffer
	tcflush(fd,TCIFLUSH);
	
	//set options to device and return
	return	(tcsetattr(fd, TCSANOW, &options) != 0) ? -1 : 0;
}

//-----------------------------------------------------------------------------
/**
  * @brief  set data bits of a package
  * @param fd: file discriptor represent the com port file
  * @param data_bits:	data bits in a package 5,6,7,8
  * @retval err code:	0-success, other - error number
  * @attention NONE
  */
int com_dev_set_data_bits(int fd, int data_bits)
{
	struct termios options;
	
	//get current options
	if (tcgetattr(fd, &options) != 0)
	{
		return -1;
	}
	//form options
	options.c_cflag &= ~CSIZE;	//clear the relative bits
	switch(data_bits)
	{
		case 5:
			options.c_cflag |= CS5;
			break;
		case 6:
			options.c_cflag |= CS6;
			break;
		case 7:
			options.c_cflag |= CS7;
			break;
		case 8:
			options.c_cflag |= CS8;
			break;
		default:
			return -1;
	}
	//discard data in the input buffer and output buffer
	tcflush(fd,TCIFLUSH);
	
	//set options to device and return
	return	(tcsetattr(fd, TCSANOW, &options) != 0) ? -1 : 0;
}
//-----------------------------------------------------------------------------
/**
  * @brief  set stop bits a package
  * @param  fd:	file discriptor represent the com port file
  * @param  stop_bits:	stop bits in a package 1,2
  * @retval err code:	0-success, other - error number
  * @attention NONE
  */
int com_dev_set_stop_bits(int fd, int stop_bits)
{
	struct termios options;
	
	//get current options
	if (tcgetattr(fd, &options) != 0)
	{
		return -1;
	}
	//form options
	switch (stop_bits)
	{
	case 1:
		options.c_cflag &= ~CSTOPB;
		break;
	case 2:
		options.c_cflag |= CSTOPB;
		break;
	default:
		return -1;
	}
	//discard data in the input buffer and output buffer
	tcflush(fd,TCIFLUSH);
	
	//set options to device and return
	return	(tcsetattr(fd, TCSANOW, &options) != 0) ? -1 : 0;
}
//-----------------------------------------------------------------------------
/**
  * @brief  set parity type of a package
  * @param  fd:	file discriptor represent the com port file
  * @param  parity
  *		@arg	'N','n':	no parity
  *		@arg	'O','o':	odd parity
  *		@arg	'E','e':	even parity
  * @retval err code: 0-success, other - error number
  * @attention NONE
  */
int com_dev_set_parity(int fd, char parity)
{
	struct termios options;
	
	//get current options
	if (tcgetattr(fd, &options) != 0)
	{
		return -1;
	}
	//form options
	options.c_iflag &= ~ISTRIP;		//do not strip parity bits(must)
	switch (parity)
	{
	case 'n':
	case 'N': //no parity
		options.c_cflag &= ~PARENB;	 //disable parity
		options.c_iflag &= ~INPCK;	 //disable input parity check
		break;
	case 'o':
	case 'O': //odd parity
		options.c_cflag |= PARENB;	//enable parity
		options.c_cflag |= PARODD;	//use odd parity
		options.c_iflag |= INPCK;	//enable input parity check
		break;
	case 'e':
	case 'E': //even parity
		options.c_cflag |=  PARENB;	//enable parity
		options.c_cflag &= ~PARODD;	//use even parity
		options.c_iflag |=  INPCK;	//enable input parity check

		break;
	default:
		return -1;
	}
	//discard data in the input buffer and output buffer
	tcflush(fd,TCIFLUSH);
	
	//set options to device and return
	return	(tcsetattr(fd, TCSANOW, &options) != 0) ? -1 : 0;
}

//-----------------------------------------------------------------------------
/**
  * @brief  set flow control type of the port
  * @param  fd:	file discriptor represent the com port file
  * @param  flow_control
  *		@arg	COM_FLOW_CONTROL_NONE:	no flow control
  *		@arg	COM_FLOW_CONTROL_HARD:	hardware flow control
  *		@arg	COM_FLOW_CONTROL_SOFT:	software flow control
  * @retval err code: 0-success, other - error number
  * @attention NONE
  */
int com_dev_set_flow_ctontrl(int fd, COM_FLOW_CONTROL_TYPE flow_control)
{
	struct termios options;
	
	//get current options
	if (tcgetattr(fd, &options) != 0)
	{
		return -1;
	}
	//form options
	switch (flow_control)
	{
	case COM_FLOW_CONTROL_NONE://disable flow control
		options.c_cflag &= ~CRTSCTS;
		options.c_iflag &= ~(IXON | IXOFF | IXANY);
		break;
	case COM_FLOW_CONTROL_HARD://enable hard flow control
		options.c_cflag |= CRTSCTS;
		options.c_iflag &= ~(IXON | IXOFF | IXANY);
		break;
	case COM_FLOW_CONTROL_SOFT://enable soft flow control
		options.c_cflag &= ~CRTSCTS;
		options.c_iflag |= IXON | IXOFF | IXANY;
		break;
	default:
		return -1;
	}
	//discard data in the input buffer and output buffer
	tcflush(fd,TCIFLUSH);
	
	//set options to device and return
	return	(tcsetattr(fd, TCSANOW, &options) != 0) ? -1 : 0;
}
/******************************END OF FILE************************************/
