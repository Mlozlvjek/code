#include "GrabImage.h"
#include <fstream>
#include <experimental/filesystem>
#include "MvCameraControl.h"
#include "Trigger.h"

using namespace std;
namespace fs = std::experimental::filesystem;

ImageRecorder::ImageRecorder(const string& configFilePath)
{
	m_enabled =true;
	m_verbose = true;
	m_outputDir ="ImageRecorder";
	createOutputDirectory();	
}

void ImageRecorder::recordImage(const cv::Mat& image, const string& tag)
{
	if (!m_enabled || image.empty()) return;

	try {
		auto now = chrono::system_clock::now();
		time_t now_time_t = chrono::system_clock::to_time_t(now);
		tm now_tm{};
#ifdef _WIN64
		localtime_s(&now_tm, &now_time_t);  // Windows
#else
		localtime_r(&now_time_t, &now_tm);  // Linux/Unix
#endif


		ostringstream filename;
		filename << m_outputDir << "/";
		if (!tag.empty()) filename << tag << "_";
		filename << put_time(&now_tm, "%Y%m%d_%H%M%S");

		auto ms = chrono::duration_cast<chrono::milliseconds>(
			now.time_since_epoch()) % 1000;
		filename << "_" << setfill('0') << setw(3) << ms.count() << ".png";

		if (!cv::imwrite(filename.str(), image) && m_verbose)
			cerr << "error: " << filename.str() << endl;
	}
	catch (const exception& e) {
		cerr << "error: " << e.what() << endl;
	}
}

bool ImageRecorder::isEnabled() const { return m_enabled; }

void ImageRecorder::createOutputDirectory()
{
	if (!fs::exists(m_outputDir)) {
		try { fs::create_directories(m_outputDir); }
		catch (const fs::filesystem_error& e) {
			cerr << "mkdir failure: " << e.what() << endl;
			m_enabled = false;
		}
	}
}
