/**

  */
#ifndef __INCLINOMETER_H
#define __INCLINOMETER_H
//============================================================================
#ifdef __cplusplus 
extern "C" {
#endif //__cplusplus
//============================================================================
//reference https://digilander.libero.it/robang/rubrica/serial.htm
#include <unistd.h>     //UNIX standard function definitions
#include <stdint.h>
//----------------------------------------------------------------------------

//============================================================================
#ifdef __cplusplus 
}
#endif //__cplusplus
//============================================================================

//#define COM_DEBUG		1

#define COM_INCLINMETER	1

struct _inclinometer_data
{
	float 				pitch;
	float				roll;
	float				tempe;
	
	int					fd;
	uint8_t 			buffer[200];	
	uint8_t 			step;
	uint8_t				data_cnt;
	uint8_t				data_len;
	uint8_t				check_sum;
	uint8_t				new_frame;
	uint8_t				frame_data[15];
} ;
typedef struct _inclinometer_data  INCLINOMETER_DATA_TypeDef;

//
int inclinometer_init_s(INCLINOMETER_DATA_TypeDef *pData);
uint8_t inclinometer_parse(INCLINOMETER_DATA_TypeDef *pData);
uint8_t inclinometer_decode(INCLINOMETER_DATA_TypeDef *pData);

//
int inclinometer_init();
uint8_t get_inclinometer_data(float *pPitch, float *pRoll, float *pTempe);

#endif //__INCLINOMETER_H
/******************************END OF FILE************************************/
