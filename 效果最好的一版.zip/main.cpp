#include "MvCameraControl.h"
#include "Trigger.h"
#include "logger.h"
#include "process.h"
#include "GrabImage.h"
#include <ctime>
#include <iomanip>

//--------------------------- ������ ---------------------------
int main() {

    ImageRecorder recorder("config.ini");
    DepthLogger depthLogger;

    MV_CC_DEVICE_INFO_LIST devList = { 0 };
    int ret = MV_CC_EnumDevices(MV_GIGE_DEVICE, &devList);
    if (MV_OK != ret || devList.nDeviceNum < 2) {
        cerr << "at least two camera: " << devList.nDeviceNum << ")" << endl;
        return -1;
    }

    vector<HikCamera> cameras;
    try {
        for (int i = 0; i < 2; ++i) {
            HikCamera cam;
            cam.deviceInfo = devList.pDeviceInfo[i];
            if (!cam.Open()) throw runtime_error("failure open camera");
            cameras.push_back(cam);
        }
    }
    catch (const exception& e) {
        cerr << "error: " << e.what() << endl;
        for (auto& cam : cameras) cam.Close();
        return -1;
    }

    //cout << "option: type Q then quit\n";

    while (true) {
        int key = cv::waitKey(2);
        if (key == 'q' || key == 'Q') break;

        vector<cv::Mat> images;
        try {
            for (size_t i = 0; i < cameras.size(); ++i) {
                cv::Mat img = cameras[i].Capture();
                if (img.empty()) throw runtime_error("capture failure");
                images.push_back(img);
            }

	    if (images.size() == 2) {
                recorder.recordImage(images[0], "left");
                recorder.recordImage(images[1], "right");
                processImages(images[0], images[1], depthLogger);
            }
        }
        catch (const exception& e) {
            cerr << "error: " << e.what() << endl;
            break;
        }
    }

    for (auto& cam : cameras) cam.Close();
    cout << "success complete" << endl;
    return 0;
}