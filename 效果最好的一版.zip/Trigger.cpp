#include "Trigger.h"
#include <string>
#include <sstream>

using namespace std;

void PrintError(const string& msg, int errCode) {
	cerr << "[ERROR] " << msg;
	if (errCode != 0) {
		cerr << " (Code:0x" << hex << errCode << ")";
	}
	cerr << endl;
}

//�������
bool HikCamera::Open()
{
	int ret = MV_CC_CreateHandle(&handle, deviceInfo);
	if (MV_OK != ret) {
		PrintError("create handle failure", ret);
		return false;
	}
	if (MV_OK != (ret = MV_CC_OpenDevice(handle))) {
		PrintError("open device failure", ret);
		DestroyHandle();
		return false;
	}

	if (!SetTriggerMode(true) || !SetTriggerSource()) {
		DestroyHandle();
		return false;
	}

	if (MV_OK != (ret = MV_CC_StartGrabbing(handle))) {
		PrintError("start to capture failure", ret);
		return false;
	}
	return true;
}

//
cv::Mat HikCamera::Capture()
{
	if (MV_OK != MV_CC_SetCommandValue(handle, "TriggerSoftware")) {
		PrintError("Trigger failure");
		return cv::Mat();
	}
	MV_FRAME_OUT stFrameData = { 0 };
	int ret = MV_CC_GetImageBuffer(handle, &stFrameData, 2000);
	if (MV_OK != ret) {
		PrintError("get image failure", ret);
		return cv::Mat();
	}

	int cvType = -1;
	if (stFrameData.stFrameInfo.enPixelType == PixelType_Gvsp_Mono8) cvType = CV_8UC1;
	else if (stFrameData.stFrameInfo.enPixelType == PixelType_Gvsp_BGR8_Packed) cvType = CV_8UC3;
	else {
		PrintError("error: 0x" + to_string(stFrameData.stFrameInfo.enPixelType));
		MV_CC_FreeImageBuffer(handle, &stFrameData);
		return cv::Mat();
	}

	cv::Mat img(
		static_cast<int>(stFrameData.stFrameInfo.nHeight),
		static_cast<int>(stFrameData.stFrameInfo.nWidth),
		cvType,
		stFrameData.pBufAddr
	);
	cv::Mat result = img.clone();
	MV_CC_FreeImageBuffer(handle, &stFrameData);
	return result;
}

//�ر����
void HikCamera::Close()
{
	if (handle) {
		MV_CC_StopGrabbing(handle);
		MV_CC_CloseDevice(handle);
		DestroyHandle();
	}
}

//
void  HikCamera::DestroyHandle() {
	if (handle) {
		MV_CC_DestroyHandle(handle);
		handle = nullptr;
	}
}

//
bool HikCamera::SetTriggerMode(bool enable) {
	int mode = enable ? MV_TRIGGER_MODE_ON : MV_TRIGGER_MODE_OFF;
	if (MV_OK != MV_CC_SetTriggerMode(handle, mode)) {
		PrintError("set trigger modle failure");
		return false;
	}
	return true;
}

bool HikCamera::SetTriggerSource() {
	if (MV_OK != MV_CC_SetTriggerSource(handle, MV_TRIGGER_SOURCE_SOFTWARE)) {
		PrintError("set trigger failure");
		return false;
	}
	return true;
}