/**

  */
#ifndef __INTERFACE_H
#define __INTERFACE_H
//============================================================================
#ifdef __cplusplus 
extern "C" {
#endif //__cplusplus
//============================================================================
#include <unistd.h>     //UNIX standard function definitions
#include <stdint.h>

#include<stdio.h>	//standard input/output definitions
#include<stdlib.h>  //standard functions
#include <string.h>

#include <sys/select.h>
#include <termios.h>
#include <stropts.h>
#include <sys/ioctl.h>
//----------------------------------------------------------------------------
#include "usart.h"
#include "inclinometer.h"
#include "sysdata_define.h"
//============================================================================
#ifdef __cplusplus 
}
#endif //__cplusplus
//============================================================================




//#define DEBUG_ON	1		//调试宏

#ifndef DEBUG_ON	
#define COM_DEBUG	1
#endif

extern INTERFACE_DATA_TypeDef interface_data;

//参数初始化模块
void init_sys(INTERFACE_DATA_TypeDef *pData);	//读入文件、初始化倾角计、电台串口

//监控模块 
//输入为manual_ctrl_cam和workmode以及vision_z
//输出为desired_cam
void monitor(INTERFACE_DATA_TypeDef *pData);	

//输出模块
void get_data_pos(INTERFACE_DATA_TypeDef *pData, 
				float cam_x, float cam_y, float cam_z, float vision_x, float vision_y, float vision_z);	//获取实时输出数据,坐标值部分
void get_data_angle(INTERFACE_DATA_TypeDef *pData,
				float cam2target_pitch, float cam2target_roll, float cam2target_azimuth);	//获取实时输出数据,角度部分
void get_data_status(INTERFACE_DATA_TypeDef *pData,
				uint8_t sys_status, float err_rep, uint8_t target_ctrl_byte);	//获取实时输出数据,状态信息部分

void output_data(INTERFACE_DATA_TypeDef *pData);//实时数据输出
void output_para(INTERFACE_DATA_TypeDef *pData);//配置参数输出
void output_info(INTERFACE_DATA_TypeDef *pData);//产品信息输出

void output_VISIONMODE_CMD(INTERFACE_DATA_TypeDef *pData);//视觉工作模式指令

int _kbhit(); 

#endif //__SYSDATA_DEFINE_H
/******************************END OF FILE************************************/
