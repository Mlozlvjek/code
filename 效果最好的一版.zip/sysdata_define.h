/**

  */
#ifndef __SYSDATA_DEFINE_H
#define __SYSDATA_DEFINE_H
//============================================================================
#ifdef __cplusplus 
extern "C" {
#endif //__cplusplus
//============================================================================
#include <unistd.h>     //UNIX standard function definitions
#include <stdint.h>
//----------------------------------------------------------------------------

//============================================================================
#ifdef __cplusplus 
}
#endif //__cplusplus
//============================================================================

#define TARGET_LED_ON	0
#define TARGET_LED_OFF	0xFF

#define WORK_MODE_DEBUG	1
#define WORK_MODE_NORM	0

#define CAM_LONG		1
#define CAM_SHORT		0

//work mode
#define AUTO_MODE		0
#define MANUAL_MODE		1

#define THD_SHORT2LONG	26	//短焦切换到长焦的距离阈值，单位m
#define THD_LONG2SHORT	25	//短焦切换到长焦的距离阈值，单位m

#define T_SEARCH_THD	5

struct _system_status_bits
{
	uint8_t pos_valid:			1;		//bit0. 定位结果是否有效: 1.有效; 0.无效 
	uint8_t rsv:				2;		//bit1~bit2. 预留 
	uint8_t workmode:			1;		//工作模式.1为调试模式，0为正常工作模式（自动切换相机）
	uint8_t current_cam:		1;		//当前定位使用相机状态，1为长焦，0为短焦
	uint8_t target_missing:		1;		//当前靶标是否丢失，1为丢失，0为正常搜索到靶标
	uint8_t exceed_thd:			1;		//当前计算重投影误差是否超过阈值，1为超过阈值，0为在阈值以内
	uint8_t rsv2:				1;		//预留
};
typedef struct _system_status_bits  SYSTEM_STATUS_BITS_TypeDef;
union SYSTEM_STATUS_TypeDef
{
	uint8_t							all;
	SYSTEM_STATUS_BITS_TypeDef		bit;
};

struct _interface_data
{
	int fd_num;		//电台串口设备号
	uint16_t frame_num;
	uint16_t frame_num_para;
	uint16_t frame_num_info;
	
	//实时输出数据
	union SYSTEM_STATUS_TypeDef sys_status;	//状态字
	float cam_x;		//摄像机坐标系下原始坐标X
	float cam_y;
	float cam_z;
	float err_rep;		//重投影误差
	float vision_x;		//视觉定位仪坐标系下坐标X
	float vision_y;
	float vision_z;
	uint8_t target_ctrl_byte;	//靶标灯光控制字
	float cam2target_pitch;		//靶标相对摄像机坐标系俯仰角
	float cam2target_roll;	
	float cam2target_azimuth;	
	float pitch;				//视觉定位仪俯仰角
	float roll;	
	//监控模块输入
	uint8_t manual_ctrl_cam;	//手动控制相机状态，1为长焦，0为短焦
	//监控模块输出
	uint8_t desired_cam;		//要求的相机状态，1为长焦，0为短焦
	
	float t_search;				//搜索时间
	
	
	//配置参数
	float camL_x;				//长焦相机安装X坐标
	float camL_y;		
	float camL_z;	
	float camS_x;				//短焦相机安装X坐标
	float camS_y;		
	float camS_z;
	float camL_pitch;			//长焦相机俯仰安装角
	float camL_azimuth;			//长焦相机水平安装角
	float camS_pitch;			//短焦相机俯仰安装角
	float camS_azimuth;			//短焦相机俯仰安装角
	float err_repL_thd;			//长焦重投影误差阈值
	float err_repS_thd;			//短焦重投影误差阈值
	float angle_thd_rad;
	
	//产品信息
	uint32_t sn;				//产品编号
	uint32_t release_date;		//出厂日期
	uint32_t hardware_ver;		//硬件版本
	uint32_t software_ver;		//软件版本
	uint32_t sn_camL;			//长焦相机序列号后4位
	uint32_t sn_camS;			//短焦相机序列号后4位
	uint32_t ver_intrinsics_camL;	//长焦相机内参文件版本
	uint32_t ver_intrinsics_camS;	//短焦相机内参文件版本
	uint32_t ver_extrinsics_camL;	//长焦相机外参文件版本
	uint32_t ver_extrinsics_camS;	//短焦相机外参文件版本	
} ;
typedef struct _interface_data  INTERFACE_DATA_TypeDef;

//


#endif //__SYSDATA_DEFINE_H
/******************************END OF FILE************************************/
