/**

  
#include<stdio.h>	//standard input/output definitions
#include<stdlib.h>  //standard functions
#include <string.h>

#include <sys/select.h>
#include <termios.h>
#include <stropts.h>
#include <sys/ioctl.h>

#include "usart.h"
#include "interface.h"
#include "inclinometer.h"
*/

#include "interface.h"

INTERFACE_DATA_TypeDef interface_data;



int _kbhit(){
    static const int STDIN = 0;
    static bool initialized = false;

    if (! initialized) {
        // Use termios to turn off line buffering
        termios term;
        tcgetattr(STDIN, &term);
        term.c_lflag &= ~ICANON;
        tcsetattr(STDIN, TCSANOW, &term);
        setbuf(stdin, NULL);
        initialized = true;
    }

    int bytesWaiting;
    //ioctl(STDIN, FIONREAD, &bytesWaiting);
    ioctl(STDIN, FIONREAD, &bytesWaiting);
    return bytesWaiting;
}



//参数初始化模块
void init_sys(INTERFACE_DATA_TypeDef *pData)	//读入文件、初始化倾角计、电台串口
{
	
	//端口号
	pData->fd_num = inclinometer_init();
	pData->frame_num = 0;
	pData->frame_num_para = 0;
	pData->frame_num_info = 0;
	
	//读入内参文件
	//TODO
	
	//读入外参文件
	//TODO
	
	
	//状态字初始化
	pData->sys_status.all = 0x0;
	pData->desired_cam = CAM_SHORT;
	
	output_VISIONMODE_CMD(pData);

}



//监控模块 
//输入为manual_ctrl_cam和workmode以及vision_z
//输出为desired_cam
void monitor(INTERFACE_DATA_TypeDef *pData)
{
	static int dcnt = 0;
	
	if(pData->sys_status.bit.workmode == MANUAL_MODE)		//
	{
		pData->t_search = 0;
	}
	else	//auto mode
	{
		if(pData->sys_status.bit.pos_valid == 1)	//pos valid
		{
			if(pData->sys_status.bit.current_cam == CAM_LONG)
			{
				if(pData->cam_z * 0.01 < THD_LONG2SHORT)
				{
					printf("cam_z : %f,  desired cam : %d",pData->cam_z, CAM_SHORT);
					pData->desired_cam = CAM_SHORT;
				}
			}
			else	//cam short
			{
				if(pData->cam_z * 0.01 > THD_SHORT2LONG)
				{
					printf("cam_z : %f,  desired cam : %d",pData->cam_z, CAM_LONG);
					pData->desired_cam = CAM_LONG;
				}
			}	
			
			pData->t_search = 0;		
		}
		else		//pos invalid
		{
			//calc t_search
			//dcnt++;
			//printf("search :%d\n", dcnt);	//test
			//printf("search :%f\n", pData->t_search);	//test
			pData->t_search += 0.000005;
			
			//continuous pos invalid for SEARCH_T_THD, then change cam
			if(pData->t_search > T_SEARCH_THD)
			{
				printf("search :%f\n", pData->t_search);	//test
				pData->t_search = 0;
				
				if(pData->sys_status.bit.current_cam == CAM_LONG)
				{
					printf("search cam change,  desired cam : %d", CAM_SHORT);
					pData->desired_cam = CAM_SHORT;
				}
				else	//cam short
				{
					printf("search cam change,  desired cam : %d", CAM_LONG);
					pData->desired_cam = CAM_LONG;
				}				
			}//end of if(pData->t_search > T_SEARCH_THD) 			
		}	//end of if(pData->sys_status.bit.pos_valid == 1)	//pos valid
	}//end of if(pData->sys_status.bit.workmode == MANUAL_MODE)		//

}	

//输出模块
//输出模块
void get_data_pos(INTERFACE_DATA_TypeDef *pData, 
				float cam_x, float cam_y, float cam_z, float vision_x, float vision_y, float vision_z)	//获取实时输出数据,坐标值部分
{
	pData->cam_x = cam_x;	//摄像机坐标系下原始X坐标
	pData->cam_y = cam_y;
	pData->cam_z = cam_z;
	pData->vision_x = vision_x;	//视觉定位仪坐标系下X坐标
	pData->vision_y = vision_y;
	pData->vision_z = vision_z;	
}

void get_data_angle(INTERFACE_DATA_TypeDef *pData,
				float cam2target_pitch, float cam2target_roll, float cam2target_azimuth)//获取实时输出数据,角度部分
{
	float tmepe;
	
	pData->cam2target_pitch = cam2target_pitch;		//靶标相对摄像机坐标系俯仰角
	pData->cam2target_roll = cam2target_roll;	
	pData->cam2target_azimuth = cam2target_azimuth;	
	
	get_inclinometer_data(&pData->pitch, &pData->roll, &tmepe);
	
//	pData->pitch = pitch;				//视觉定位仪俯仰角
//	pData->roll = roll;			
}


void get_data_status(INTERFACE_DATA_TypeDef *pData,
				uint8_t sys_status, float err_rep, uint8_t target_ctrl_byte)	//获取实时输出数据,状态信息部分
{
	pData->sys_status.all = sys_status;	//状态字
	pData->err_rep = err_rep;		//重投影误差
	pData->target_ctrl_byte = target_ctrl_byte;	//靶标灯光控制字
}

void output_data(INTERFACE_DATA_TypeDef *pData)//实时数据输出
{
	uint8_t send_buf[60];
	uint16_t u16_tmp = 0;
	int16_t i16_tmp = 0;
	uint8_t index = 0;
	
	static uint8_t cnt_cmd = 0;
	
	//head
	send_buf[index++] = 0x55;
	send_buf[index++] = 0xAA;
	//len
	send_buf[index++] = 0x1F;
	//type
	send_buf[index++] = 0xF0;
	//frame num
	send_buf[index++] = pData->frame_num & 0xFF;
	send_buf[index++] = (pData->frame_num >> 8) & 0xFF;
	pData->frame_num++;
	//data
	send_buf[index++] = pData->sys_status.all;
	
	i16_tmp = (int16_t)pData->cam_x;
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;	
	
	i16_tmp = (int16_t)pData->cam_y;
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;		
	
	i16_tmp = (int16_t)pData->cam_z;
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;		

	u16_tmp = (uint16_t)(pData->err_rep * 1000);
	send_buf[index++] = u16_tmp & 0xFF;
	send_buf[index++] = (u16_tmp >> 8) & 0xFF;	
	
	i16_tmp = (int16_t)pData->vision_x;
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;		
	
	i16_tmp = (int16_t)pData->vision_y;
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;		
	
	i16_tmp = (int16_t)pData->vision_z;
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;	

	send_buf[index++] = pData->target_ctrl_byte;

	i16_tmp = (int16_t)(pData->cam2target_pitch * 100);
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;	

	i16_tmp = (int16_t)(pData->cam2target_roll * 100);
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;	

	i16_tmp = (int16_t)(pData->cam2target_azimuth * 100);
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;	
	
	i16_tmp = (int16_t)(pData->pitch * 100);
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;	

	i16_tmp = (int16_t)(pData->roll * 100);
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;		
	
	//check sum
	uint16_t chk_sum = 0;
	for(uint8_t i = 0; i < index; i++)
	{
		chk_sum += send_buf[i];
	}
	
	send_buf[index++] = chk_sum & 0xFF;
	send_buf[index++] = (chk_sum >> 8) & 0xFF;	
	
	//send buf data
	com_tx(pData->fd_num, send_buf, index);	
	
	cnt_cmd++;
	if(cnt_cmd >= 10)
	{
		cnt_cmd = 0;
		output_VISIONMODE_CMD(pData);
	}
	
}

void output_para(INTERFACE_DATA_TypeDef *pData)//配置参数输出
{
	uint8_t send_buf[60];
	uint16_t u16_tmp = 0;
	int16_t i16_tmp = 0;
	uint8_t index = 0;
	
	//head
	send_buf[index++] = 0x55;
	send_buf[index++] = 0xAA;
	//len
	send_buf[index++] = 0x1F;
	//type
	send_buf[index++] = 0xF1;
	//frame num
	send_buf[index++] = pData->frame_num_para & 0xFF;
	send_buf[index++] = (pData->frame_num_para >> 8) & 0xFF;
	pData->frame_num_para++;
	//data
	send_buf[index++] = pData->sys_status.all;
	
	i16_tmp = (int16_t)pData->camL_x;
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;	
	
	i16_tmp = (int16_t)pData->camL_y;
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;		
	
	i16_tmp = (int16_t)pData->camL_z;
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;	

	i16_tmp = (int16_t)pData->camS_x;
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;	

	i16_tmp = (int16_t)pData->camS_y;
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;	

	i16_tmp = (int16_t)pData->camS_z;
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;	
	
	i16_tmp = (int16_t)(pData->camL_pitch * 1000);
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;		

	i16_tmp = (int16_t)(pData->camL_azimuth * 1000);
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;		

	i16_tmp = (int16_t)(pData->camS_pitch * 1000);
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;			

	i16_tmp = (int16_t)(pData->camS_azimuth * 1000);
	send_buf[index++] = i16_tmp & 0xFF;
	send_buf[index++] = (i16_tmp >> 8) & 0xFF;	
		
	u16_tmp = (uint16_t)(pData->err_repL_thd * 1000);
	send_buf[index++] = u16_tmp & 0xFF;
	send_buf[index++] = (u16_tmp >> 8) & 0xFF;	

	u16_tmp = (uint16_t)(pData->err_repS_thd * 1000);
	send_buf[index++] = u16_tmp & 0xFF;
	send_buf[index++] = (u16_tmp >> 8) & 0xFF;	
	
	send_buf[index++] = 0x00;
	send_buf[index++] = 0x00;
	
	//check sum
	uint16_t chk_sum = 0;
	for(uint8_t i = 0; i < index; i++)
	{
		chk_sum += send_buf[i];
	}
	
	send_buf[index++] = chk_sum & 0xFF;
	send_buf[index++] = (chk_sum >> 8) & 0xFF;	
	
	//send buf data
	com_tx(pData->fd_num, send_buf, index);		
}

uint16_t date2u16(uint32_t date)
{
	uint16_t result;
	uint16_t year;
	uint8_t month;
	uint8_t day;
	uint8_t inc_year;
	
	year = (date / 10000) % 2099;
	month = (date / 100) % 99;
	day = date % 100;
	
	inc_year = year - 2020;
	
	result = (inc_year << 12) + ((month & 0x0F) << 8) + day;
	
	return result;
}

void output_info(INTERFACE_DATA_TypeDef *pData)//产品信息输出
{
	uint8_t send_buf[60];
	uint16_t u16_tmp = 0;
	int16_t i16_tmp = 0;
	uint8_t index = 0;

	
	//head
	send_buf[index++] = 0x55;
	send_buf[index++] = 0xAA;
	//len
	send_buf[index++] = 0x1F;
	//type
	send_buf[index++] = 0xF2;
	//frame num
	send_buf[index++] = pData->frame_num_info & 0xFF;
	send_buf[index++] = (pData->frame_num_info >> 8) & 0xFF;
	pData->frame_num_info++;
	//data
		
	u16_tmp = (uint16_t)pData->sn;
	send_buf[index++] = u16_tmp & 0xFF;
	send_buf[index++] = (u16_tmp >> 8) & 0xFF;	
	
	u16_tmp = date2u16(pData->release_date);
	send_buf[index++] = u16_tmp & 0xFF;
	send_buf[index++] = (u16_tmp >> 8) & 0xFF;	

	u16_tmp = date2u16(pData->hardware_ver);
	send_buf[index++] = u16_tmp & 0xFF;
	send_buf[index++] = (u16_tmp >> 8) & 0xFF;	
	
	u16_tmp = date2u16(pData->software_ver);
	send_buf[index++] = u16_tmp & 0xFF;
	send_buf[index++] = (u16_tmp >> 8) & 0xFF;		

	u16_tmp = date2u16(pData->sn_camL);
	send_buf[index++] = u16_tmp & 0xFF;
	send_buf[index++] = (u16_tmp >> 8) & 0xFF;	

	u16_tmp = date2u16(pData->sn_camS);
	send_buf[index++] = u16_tmp & 0xFF;
	send_buf[index++] = (u16_tmp >> 8) & 0xFF;	

	u16_tmp = date2u16(pData->ver_intrinsics_camL);
	send_buf[index++] = u16_tmp & 0xFF;
	send_buf[index++] = (u16_tmp >> 8) & 0xFF;	

	u16_tmp = date2u16(pData->ver_intrinsics_camS);
	send_buf[index++] = u16_tmp & 0xFF;
	send_buf[index++] = (u16_tmp >> 8) & 0xFF;	

	u16_tmp = date2u16(pData->ver_extrinsics_camL);
	send_buf[index++] = u16_tmp & 0xFF;
	send_buf[index++] = (u16_tmp >> 8) & 0xFF;	

	u16_tmp = date2u16(pData->ver_extrinsics_camS);
	send_buf[index++] = u16_tmp & 0xFF;
	send_buf[index++] = (u16_tmp >> 8) & 0xFF;	
	
	send_buf[index++] = 0x00;
	send_buf[index++] = 0x00;
	send_buf[index++] = 0x00;
	send_buf[index++] = 0x00;
	send_buf[index++] = 0x00;
	send_buf[index++] = 0x00;
	
	//check sum
	uint16_t chk_sum = 0;
	for(uint8_t i = 0; i < index; i++)
	{
		chk_sum += send_buf[i];
	}
	
	send_buf[index++] = chk_sum & 0xFF;
	send_buf[index++] = (chk_sum >> 8) & 0xFF;	
	
	//send buf data
	com_tx(pData->fd_num, send_buf, index);		
}

void output_VISIONMODE_CMD(INTERFACE_DATA_TypeDef *pData)//视觉工作模式指令
{
	//暂不启用
//	uint8_t send_buf[10];
//	uint8_t index = 0;	
//	//head
//	send_buf[index++] = 0xEB;
//	send_buf[index++] = 0x90;
//	//len
//	send_buf[index++] = 0x04;
//	//type
//	send_buf[index++] = 0x03;
//
//	send_buf[index++] = 0x48;
//	
//	send_buf[index++] = 0xCA;
//	send_buf[index++] = 0x01;
//	
//	//send buf data
//	com_tx(pData->fd_num, send_buf, index);		
}






/******************************END OF FILE************************************/
