#include "MvCameraControl.h"
#include "Trigger.h"
#include "logger.h"
#include "process.h"
#include "GrabImage.h"
#include <ctime>
#include <iomanip>
#include <iostream>
#include <vector>
#include <opencv2/opencv.hpp>
#include <chrono>
#include <fstream>
#include <string>
#include <memory>
#include <iomanip>
#include <sstream>
#include <ctime>
#include <thread>
#include <mutex>
#include <queue>
#include <condition_variable>
#include <atomic>



using namespace std;

//--------------------------- ȫ�ֱ�����ͬ��ԭ�� ---------------------------
atomic<bool> g_exit(false);
mutex queue_mutex;
condition_variable queue_cv;
queue<pair<cv::Mat, cv::Mat>> image_pair_queue;
const int MAX_QUEUE_SIZE = 10;

//--------------------------- �̺߳��� ---------------------------
void readThreadFunction(vector<HikCamera>& cameras) {
	ImageRecorder recorder("config.ini");
	while (!g_exit) {
		vector<cv::Mat> images;
		for (size_t i = 0; i < cameras.size(); ++i) {
			cv::Mat img = cameras[i].Capture();
			if (img.empty()) {
				cerr << "Failed to capture image from camera " << i << endl;
				continue;
			}
			images.push_back(img);
		}

		if (images.size() == 2) {
			unique_lock<mutex> lock(queue_mutex);
			// ��������������Ƴ���ɵ�һ��ͼ��
			if (image_pair_queue.size() >= MAX_QUEUE_SIZE) {
				image_pair_queue.pop();
			}
			image_pair_queue.push(make_pair(images[0], images[1]));
			recorder.recordImage(images[0], "left");
			recorder.recordImage(images[1], "right");
			lock.unlock();
			queue_cv.notify_one();  // ֪ͨһ�������߳�
		}
		this_thread::sleep_for(chrono::milliseconds(10)); // �������ռ��CPU
	}
}

void processThreadFunction(int threadId) {
	ImageRecorder recorder("config.ini");
	DepthLogger depthLogger;
	while (!g_exit) {
		pair<cv::Mat, cv::Mat> imagePair;
		{
			unique_lock<mutex> lock(queue_mutex);
			// �ȴ������������ݻ�����˳�
			queue_cv.wait(lock, [] {
				return !image_pair_queue.empty() || g_exit;
			});

			if (g_exit && image_pair_queue.empty()) return;

			imagePair = image_pair_queue.front();
			image_pair_queue.pop();
		}

		// �����߳�ID����Ա����
		//cout << "Processing in thread " << threadId << "..." << endl;
		processImages(imagePair.first, imagePair.second, depthLogger);
	}
}

//--------------------------- ������ ---------------------------
int main() {

	ImageRecorder recorder("config.ini");
	DepthLogger depthLogger;

	MV_CC_DEVICE_INFO_LIST devList = { 0 };
	int ret = MV_CC_EnumDevices(MV_GIGE_DEVICE, &devList);
	if (MV_OK != ret || devList.nDeviceNum < 2) {
		cerr << "at least two camera: " << devList.nDeviceNum << ")" << endl;
		return -1;
	}

	vector<HikCamera> cameras;
	try {
		for (int i = 0; i < 2; ++i) {
			HikCamera cam;
			cam.deviceInfo = devList.pDeviceInfo[i];
			if (!cam.Open()) throw runtime_error("failure open camera");
			cameras.push_back(cam);
		}
	}
	catch (const exception& e) {
		cerr << "error: " << e.what() << endl;
		for (auto& cam : cameras) cam.Close();
		return -1;
	}

	//cout << "option: type Q then quit\n";
	// ������ȡ�߳�
	thread reader_thread(readThreadFunction, ref(cameras));

	// ������������߳�
	vector<thread> processor_threads;
	for (int i = 0; i < 5; ++i) {
		processor_threads.emplace_back(processThreadFunction, i);
	}


	// ���̵߳ȴ��˳��ź�
	while (true) {
		char key = cin.get();
		if (key == 'q' || key == 'Q') {
			g_exit = true;
			break;
		}
	}

	// ֪ͨ�����߳��˳�
	queue_cv.notify_all();

	// �ȴ��߳̽���
	reader_thread.join();
	for (auto& t : processor_threads) {
		t.join();
	}

	// ������Դ
	for (auto& cam : cameras) {
		cam.Close();
		cout << "Camera closed." << endl;
	}
}

/*
while (true) {
		int key = cv::waitKey(2);
		if (key == 'q' || key == 'Q') break;

		vector<cv::Mat> images;
		try {
			for (size_t i = 0; i < cameras.size(); ++i) {
				cv::Mat img = cameras[i].Capture();
				if (img.empty()) throw runtime_error("capture failure");
				images.push_back(img);
			}

		if (images.size() == 2) {
				recorder.recordImage(images[0], "left");
				recorder.recordImage(images[1], "right");
				processImages(images[0], images[1], depthLogger);
			}
		}
		catch (const exception& e) {
			cerr << "error: " << e.what() << endl;
			break;
		}
	}

	for (auto& cam : cameras) cam.Close();
	cout << "success complete" << endl;
	return 0;
}
*/