#include "MvCameraControl.h"
#include <opencv2/opencv.hpp>
#include<string>
#include<iostream>

//������Ϣ
void PrintError(const std::string& msg, int errCode = 0);

//������
class HikCamera
{
public:
	void* handle = nullptr;
	MV_CC_DEVICE_INFO* deviceInfo = nullptr;

	bool Open();
	cv::Mat Capture();
	void Close();

private:
	void DestroyHandle();
	bool SetTriggerMode(bool enable);
	bool SetTriggerSource();
};

