#include <string>
#include <opencv2/opencv.hpp>
using namespace std;
//--------------------------- ͼ���¼�� ---------------------------
class ImageRecorder 
{
public:
	ImageRecorder(const string& configFilePath);
	void recordImage(const cv::Mat& image, const string& tag = "");

	bool isEnabled() const;
private:
	bool m_enabled = false;
	bool m_verbose = false;
	string m_outputDir = "recorded_images";
	void createOutputDirectory();
};
