#include"logger.h"
#include <chrono>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include"process.h"
using namespace std;


string DepthLogger::get_log_filename()
{
	auto now = chrono::system_clock::now();
	time_t now_c = chrono::system_clock::to_time_t(now);
	tm tm{};
#ifdef _WIN64
	localtime_s(&tm, &now_c); // Windows
#else
	localtime_r(&now_c, &tm); // Linux/Unix
#endif
	stringstream ss;
	ss << put_time(&tm, "log_%Y%m%d_%H%M%S.csv");
	return ss.str();
}



DepthLogger::DepthLogger()
{
	roll_log_file();
}

DepthLogger::~DepthLogger()
{
	if (log_file.is_open()) log_file.close();
}

// DepthLogger.cpp �޸� roll_log_file ����
void DepthLogger::roll_log_file() {
    if (log_file.is_open()) {
        log_file.flush(); // ȷ������д�����
        log_file.close();
    }

    string new_file = get_log_filename();
    
    // �����ļ�·��������ڵ���
    //std::cout << "create: " << fs::absolute(new_file) << std::endl;

    // ��鲢ɾ�����ļ�
    if (log_files.size() >= MAX_LOG_FILES) {
        const auto& old_file = log_files.front();
        if (fs::exists(old_file)) {
            fs::remove(old_file);
        }
        log_files.erase(log_files.begin());
    }

    // ʹ�� trunc ģʽȷ�����ļ�
    log_file.open(new_file, ios::out | ios::trunc); // �ؼ��޸�
    if (!log_file) {
        throw runtime_error("failure to create: " + new_file);
    }
    
    // д�� CSV ͷ
    log_file << "timestamp,left_x,left_y,right_x,right_y,disparity,depth_mm\n";
    log_file.flush(); // ����ˢ��ͷ��
    
    log_files.push_back(new_file);
    create_time = chrono::system_clock::now();
}

void DepthLogger::write(const ImageFeature& featL, const ImageFeature& featR, double disparity, double depth)
{
	auto now = chrono::system_clock::now();
	if (chrono::duration_cast<chrono::seconds>(now - create_time).count() > LOG_ROLLING_SECONDS) {
		roll_log_file();
	}

	if (log_file) {
		time_t now_c = chrono::system_clock::to_time_t(now);
		tm tm{};
		#ifdef _WIN64
		localtime_s(&tm, &now_c); // Windows
		#else
		localtime_r(&now_c, &tm); // Linux/Unix
		#endif

		log_file << put_time(&tm, "%Y-%m-%d %H:%M:%S") << ","
			<< featL.centroid.x << "," << featL.centroid.y << ","
			<< featR.centroid.x << "," << featR.centroid.y << ","
			<< disparity << "," << depth << "\n";
	// ����д��ȷ��
    if (!log_file) {
        cerr << "faliure��eeror code: " << strerror(errno) << endl;
    }
    log_file.flush(); // ÿ��д���ǿ��ˢ��
	}
}

