#include "process.h"
#include <vector>
#include "interface.h"
#include "inclinometer.h"

cv::Mat cameraMatrixR = (cv::Mat_<double>(3, 3) <<
		4678.63,	0.00,	2033.69,
			0.00,	4673.53,	1536.91,
			0.00,	0.00,	1.00);

cv::Mat distCoeffR = (cv::Mat_<double>(5, 1) <<
	 -0.054312, 0.139720, -0.000352, 0.000083, 0);

cv::Mat cameraMatrixL = (cv::Mat_<double>(3, 3) <<
	4684.85,	0.00,	2042.53,
			0.00,	4680.57,	1521.12,
			0.00,	0.00,	1.00);

cv::Mat distCoeffL = (cv::Mat_<double>(5, 1) <<
	 -0.056509, 0.137856, 0.000171, 0.000487,0);

cv::Mat T = (cv::Mat_<double>(3, 1) <<
	-56.7314, -0.2259, 8.8731);

cv::Mat R = (cv::Mat_<double>(3, 3) <<
	1, -0.000978, -0.005,
	0.0000989, 1, 0.0021,
	0.005, -0.0021, 1);

cv::Mat Tj= (cv::Mat_<double>(3, 1) <<
	-27, -10.5, -12.8);

cv::Mat Rj = (cv::Mat_<double>(3, 3) <<
	0.999995,0.000000,0.003050,
         0.000003,0.999999,-0.001043,
         -0.003050,0.001043,0.999995);

using namespace std;

ImageFeature findLightTargetCenter(const cv::Mat& inputImage) {
	cv::Mat gray;
	if (inputImage.channels() == 3)
		cv::cvtColor(inputImage, gray, cv::COLOR_BGR2GRAY);
	else
		gray = inputImage.clone();

	cv::Mat binary;
	cv::threshold(gray, binary, 200, 255, cv::THRESH_BINARY); 

	cv::Mat kernel = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5, 5));
	cv::morphologyEx(binary, binary, cv::MORPH_OPEN, kernel);

	std::vector<std::vector<cv::Point>> contours;
	cv::findContours(binary, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

	ImageFeature targetCenter;
	for (const auto& contour : contours) {
		double area = cv::contourArea(contour);
		//if (area < 100) continue;

		double perimeter = cv::arcLength(contour, true);
		double circularity = 4 * CV_PI * area / (perimeter * perimeter);

		if (circularity > 0.5) {  
			cv::Moments M = cv::moments(contour);
			targetCenter.centroid = cv::Point2f(static_cast<float>(M.m10 / M.m00),
				static_cast<float>(M.m01 / M.m00));
			break;  
		}
	}
	return targetCenter;
}

void processImages(const cv::Mat& img1, const cv::Mat& img2, DepthLogger& logger)
{
	//cv::Mat pingjie;
	//cv::hconcat(img1, img2, pingjie); 
    	//cv::resize(pingjie, pingjie, cv::Size(), 0.2, 0.2, cv::INTER_AREA);
	//cv::imshow("The scaled image",pingjie);

	double alpha =0.52; 
	cv::Rect validRoi[2];
	cv::Size imageSize(4096, 3000);
	cv::Mat Rl, Rr, Pl, Pr, Q;
	cv::stereoRectify(cameraMatrixL, distCoeffL, cameraMatrixR, distCoeffR, imageSize, R, T, Rl, Rr, Pl, Pr, Q, cv::CALIB_ZERO_DISPARITY, alpha, imageSize, &validRoi[0], &validRoi[1]);	
	cv::Mat mapLx, mapLy, mapRx, mapRy;
	cv::initUndistortRectifyMap(cameraMatrixL, distCoeffL, Rl, Pl,imageSize, CV_32FC1, mapLx, mapLy);
	cv::initUndistortRectifyMap(cameraMatrixR, distCoeffR, Rr, Pr,imageSize, CV_32FC1, mapRx, mapRy);
	cv::Mat imgL, imgR;
	cv::remap(img1, imgL, mapLx, mapLy, cv::INTER_LINEAR);
	cv::remap(img2, imgR, mapRx, mapRy, cv::INTER_LINEAR);
	cv::Mat rectifiedL = imgL(validRoi[0]);  
	cv::Mat rectifiedR = imgR(validRoi[1]);

	ImageFeature feat = findLightTargetCenter(img1);
	ImageFeature featL = findLightTargetCenter(rectifiedL);
	ImageFeature featR = findLightTargetCenter(rectifiedR);

	double fx = cameraMatrixL.at<double>(0, 0);
	double baseline = -T.at<double>(0, 0); //mm
	double fx_baseline = fx * baseline;
	double cx = cameraMatrixL.at<double>(0, 2);
	double cy = cameraMatrixL.at<double>(1, 2);
	double disparity = 0;
	double Z = -1;
	disparity = abs(featR.centroid.x - featL.centroid.x);
	//std::cout<<disparity<<std::endl;
	Z = fx_baseline / disparity;
	double X = (cx - feat.centroid.x) * baseline / disparity;
	double Y = (cy - feat.centroid.y) * baseline / disparity;

	cv::Mat locl = (cv::Mat_<double>(3, 1) << X, Y, Z);	
	double x, y, z;
	cv::Mat loc = Rj * locl + Tj;
	x = loc.at<double>(0, 0);
	y = loc.at<double>(1, 0);
	z = loc.at<double>(2, 0);

	z = z / 10;	
	init_sys(&interface_data);
	get_data_pos(&interface_data, (float)x, (float)y, (float)z, 0, 0, 0);
	interface_data.sys_status.bit.target_missing = 1;
	interface_data.sys_status.bit.exceed_thd = 0;
	interface_data.sys_status.bit.pos_valid = 0;	
	get_data_angle(&interface_data, 0,0,0);
	output_data(&interface_data);	

	cout << "location: (" << x / 1000 << ", " << y / 1000 << ", " << z / 100 << ")\n";
	logger.write(featL, featR, disparity, z);
}