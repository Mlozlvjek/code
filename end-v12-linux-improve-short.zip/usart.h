/**
  * @file		uart.h
  * @author		Hill
  * @copyright	Hill
  * @date		2021-03-23
  * @version	V1.0
  * @brief		uart basic operation
  * @attention	NONE
  */
#ifndef __UART_H
#define __UART_H
//============================================================================
#ifdef __cplusplus 
extern "C" {
#endif //__cplusplus
//============================================================================
//reference https://digilander.libero.it/robang/rubrica/serial.htm
#include<unistd.h>     //UNIX standard function definitions
//----------------------------------------------------------------------------
#define COM1 0
#define COM2 1
#define COM3 2
//----------------------------------------------------------------------------
typedef enum
{
	COM_FLOW_CONTROL_NONE = 0,
	COM_FLOW_CONTROL_HARD = 1,
	COM_FLOW_CONTROL_SOFT = 2
}COM_FLOW_CONTROL_TYPE;
//----------------------------------------------------------------------------
int com_open(int com_num, int baud_rate,int data_bits, int stop_bits,
			 char parity, COM_FLOW_CONTROL_TYPE flow_control);
#define com_close(fd)		close(fd)
#define com_rx(fd,buf,len)	read(fd,buf,len)
#define com_tx(fd,buf,len)	write(fd,buf,len)
//============================================================================
#ifdef __cplusplus 
}
#endif //__cplusplus
//============================================================================

#endif //__UART_H
/******************************END OF FILE************************************/
