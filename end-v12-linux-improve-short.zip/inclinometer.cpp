/**

  */
extern "C" {
#include "usart.h"
#include "inclinometer.h"
}

#include<stdio.h>	//standard input/output definitions
#include<stdlib.h>  //standard functions
#include <string.h>

INCLINOMETER_DATA_TypeDef	incl_data;

int inclinometer_init_s(INCLINOMETER_DATA_TypeDef *pData)
{
	int result = 0;
	
	pData->pitch = 0.0;
	pData->roll = 0.0;
	pData->tempe = 0.0;

	pData->fd = 0;
	pData->buffer[0] = 0;	
	pData->step = 0;
	pData->data_cnt = 0;
	pData->data_len = 0;
	pData->check_sum = 0;
	pData->new_frame = 0;
	
	pData->frame_data[0] = 0;	
	
	
	result = com_open(COM_INCLINMETER, 115200, 8, 1,
			 'N', COM_FLOW_CONTROL_NONE);		//ubuntu
	
	pData->fd = result;
	
	#ifdef COM_DEBUG
	
	if (pData->fd == -1)
	{
		printf("\nopen COM failed!\n");
		pause();
		return -1;
	}
	else
	{
		printf("\nCOM%d open succeeded! fd :%d\n", COM_INCLINMETER, pData->fd);
		usleep(100000);//sleep 100ms
		printf("Inclinometer Working.\n");

	}			
		
	
	#endif
	
	return result;
}

uint8_t inclinometer_parse(INCLINOMETER_DATA_TypeDef *pData)
{
	int nread = 0;
	int i = 0;
	uint8_t byte_new = 0;
	uint8_t chk_sum = 0;
	uint8_t new_data = 0;
	nread = com_rx(pData->fd, pData->buffer, sizeof(pData->buffer));	//ubuntu

	#ifdef COM_DEBUG
	int k = 0;
	char tmp[200] = {0x0};
	char new_byte[5];
	
	for(k = 0; k < nread; k++)
	{
		sprintf(new_byte,"%02x ", pData->buffer[k]);
		strcat(tmp, new_byte);
	}
	printf("\n%s\n",tmp);
	#endif

	
	for(i = 0; i < nread; i++)
	{
		byte_new = pData->buffer[i];
		switch(pData->step)
		{
			case 0:	//head
				if(byte_new == 0x68)
				{
					pData->step++;
					pData->frame_data[0] = byte_new;
				}

				pData->data_cnt = 0;

				
				break;
			case 1:	//data len
				pData->step++;
				pData->frame_data[1] = byte_new;			
				pData->data_len = byte_new;
				pData->data_cnt++;
				break;
				
			case 2: //data
				pData->frame_data[1 + pData->data_cnt] = byte_new;	
				pData->data_cnt++;
				
				if(pData->data_cnt >= pData->data_len)	
				{
					chk_sum = 0;
					for(int k = 1; k < pData->data_cnt; k++)
					{
						chk_sum += pData->frame_data[k];
					}
					
					if(chk_sum == pData->frame_data[pData->data_len])	//check sum pass
					{
						new_data = 1;
						inclinometer_decode(pData);
					}		
					pData->step = 0;
					
					#ifdef COM_DEBUG
					printf("\n parse frame, date len: %d. frame:\n", pData->data_len);
					for(int k = 0; k < pData->data_len + 1; k++)
					{
						printf("%02x ", pData->frame_data[k]);
					}
					printf("\n");
					printf("\n chk_sum: %02x, received chk_sum: %02x.\n", chk_sum, pData->frame_data[pData->data_len]);
					
					#endif
								
				}								
				
				break;
			default:
				break;
						
		}//end of switch
		
	}//end of for
	
	return new_data;

}

void get_BCD(uint8_t buf[], float *pData)
{
	uint8_t digit_p01, digit_p1, digit_1, digit_10, digit_100, digit_signed;
	
	digit_p01 = buf[2] % 16;
	digit_p1 = buf[2] / 16;
	digit_1 = buf[1] % 16;
	digit_10 = buf[1] / 16;
	digit_100 = buf[0] % 16;
	digit_signed = buf[0] / 16;
	
	if(digit_signed == 0)
	{
		*pData = (digit_100 * 100 + digit_10 * 10 + digit_1 + 0.1 * digit_p1 + 0.01 * digit_p01);
	}
	else
	{
		*pData = -1.0 * (digit_100 * 100 + digit_10 * 10 + digit_1 + 0.1 * digit_p1 + 0.01 * digit_p01);
	}
	return;
	
}

uint8_t inclinometer_decode(INCLINOMETER_DATA_TypeDef *pData)
{
	if((pData->frame_data[0] == 0x68) && (pData->frame_data[1] == 0x0D) && (pData->frame_data[2] == 0) &&
		(pData->frame_data[3] == 0x84))	//valid reply frame
	{
		get_BCD(&pData->frame_data[4], &pData->roll);
		get_BCD(&pData->frame_data[7], &pData->pitch);
		get_BCD(&pData->frame_data[10], &pData->tempe);
	}
}


int inclinometer_init()
{
	return inclinometer_init_s(&incl_data);
}

uint8_t get_inclinometer_data(float *pPitch, float *pRoll, float *pTempe)
{
	uint8_t new_data = 0;
	new_data = inclinometer_parse(&incl_data);
	if(new_data != 0)
	{
		*pPitch = incl_data.pitch;
		*pRoll = incl_data.roll;
		*pTempe = incl_data.tempe;			
	}
	
	return new_data;		// 0 means no new data.
}






/******************************END OF FILE************************************/
